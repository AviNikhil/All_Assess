package com.infinite.VizagMuncipalCorp.service;

import java.util.List;

import com.infinite.VizagMuncipalCorp.model.User;

public interface IUserService {
//service methpod interface creation
	
	public User InsertRecord(String username,String password);
	public List<User> getComplaints();
}
