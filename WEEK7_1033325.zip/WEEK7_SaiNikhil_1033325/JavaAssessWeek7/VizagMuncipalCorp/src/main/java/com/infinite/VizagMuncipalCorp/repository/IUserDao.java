package com.infinite.VizagMuncipalCorp.repository;

import java.util.List;

import com.infinite.VizagMuncipalCorp.model.User;

public interface IUserDao {
	//USER DAO INTERFACE CREATION
	public User InsertRecord(String username,String password); //INSERT VALIDATION METHOD
	public List<User> getComplaints(); //COMPLAINT INTAKE METHOD

}
