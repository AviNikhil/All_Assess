package com.infinite.VizagMuncipalCorp.service;

import java.util.List;

import com.infinite.VizagMuncipalCorp.model.User;
import com.infinite.VizagMuncipalCorp.repository.UserDaoImpl;

public class UserServiceImpl implements IUserService{
    UserDaoImpl userdao = new UserDaoImpl();
	@Override
	public User InsertRecord(String username,String password) {
		
		userdao.InsertRecord(username, password);
		return null;
	}

	@Override
	public List<User> getComplaints() {
		// TODO Auto-generated method stub
		return userdao.getComplaints();
	}

}
