package com.infinite.VizagMuncipalCorp.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.infinite.VizagMuncipalCorp.model.User;

public class UserDaoImpl implements IUserDao{
	
	@Autowired
	private SessionFactory sfactory;
	public void setSfactory(SessionFactory sfactory) {
		this.sfactory = sfactory;
	}
	@Override
	public User InsertRecord(String username,String password) {
		 Session session = sfactory.getCurrentSession();
		User user = new User();
	    user.setUsername(username);
	    user.setPassword(password);
	    session.save(user);
		return user;
	}

	@Override
	public List<User> getComplaints() {
		Session ses = this.sfactory.getCurrentSession();
		List<User> ls= ses.createQuery("from GVMCUSER").list();
		return ls;
		
	}

}
