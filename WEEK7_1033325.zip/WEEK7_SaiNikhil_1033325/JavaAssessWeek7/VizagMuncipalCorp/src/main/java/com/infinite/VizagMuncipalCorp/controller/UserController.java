package com.infinite.VizagMuncipalCorp.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.VizagMuncipalCorp.model.User;
import com.infinite.VizagMuncipalCorp.service.UserServiceImpl;

@Controller
public class UserController {
	
	UserServiceImpl userservice = new UserServiceImpl();
	@RequestMapping(value = "/", method = RequestMethod.GET, headers = "Accept=application/json")
	public String goToHomePage() {
		return "redirect:/login";
	}
		
		/**
		 * @param model
		 * @return
		 */
		@RequestMapping(value = "/login", method = RequestMethod.GET)
		public String InsertRecord(Model model) {
			model.addAttribute("User", new User()); //create add model attribute to user
			String username = null;
			String password=null;
			model.addAttribute("Home", userservice.InsertRecord(username, password));
			return "about";
		}
		
		@RequestMapping(value = "/display", method = RequestMethod.GET)
		public String getComplaints(Model model) {
			model.addAttribute("User", new User());
			model.addAttribute("ListOfComplaints", userservice.getComplaints());
			return "complaint";
		}
	}

