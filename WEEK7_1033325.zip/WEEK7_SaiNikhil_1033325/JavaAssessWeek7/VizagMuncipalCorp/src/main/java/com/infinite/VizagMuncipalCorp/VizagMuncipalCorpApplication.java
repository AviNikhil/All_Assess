package com.infinite.VizagMuncipalCorp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VizagMuncipalCorpApplication {

	public static void main(String[] args) {
		SpringApplication.run(VizagMuncipalCorpApplication.class, args);

	}

}
