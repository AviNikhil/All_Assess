import React, { useState, useEffect } from "react";
import Service from "./Service";
function Component() {
    const [table, setComponent] = useState([])

    useEffect(() => {
        getComponent()
    }, [])
    const getComponent = () => {
        Service.getComponent().then((response) => {

            setComponent(response.data.data)
            console.log(response.data.data);
        });
    }
    return (
        <div>
            <center><h1>Table</h1></center>
            <table border="1" align="center">
                <thead>
                    <tr>
                        <th>ID Nation</th>
                        <th>Population</th>
                        <th>Year</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        table.map(
                            table =>
                                <tr key={table.Year}>
                                    <td>{table["ID Nation"]}</td>
                                    <td>{table.Population}</td>
                                    <td>{table.Year}</td>
                                </tr>
                        )
                    }
                </tbody>
            </table >
        </div >
    );
}
export default Component