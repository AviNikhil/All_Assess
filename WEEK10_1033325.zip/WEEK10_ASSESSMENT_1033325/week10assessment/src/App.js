import './App.css';
import Component from './Component';
import Loading from './Loading';
import Pharma from './Pharma';
function App() {
  return (
   <div>
     <Loading/>
   </div>
  );
}

export default App;
