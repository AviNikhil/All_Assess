import React from "react";
import './Pharma.css';
class Pharma extends React.Component{
    constructor(){
        super();
        this.state={
            fields:{},
            errors:{}
        }
        this.handleChange = this.handleChange.bind(this);
        this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);
    };
    handleChange(e){
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields
        });
    }
    submituserRegistrationForm(e){
        e.preventDefault();
            if(this.validateForm()){
                  alert("form submited succesfully");
            }
    }
    validateForm(){
        let fields=this.state.fields
        let fvalid=true;
        let errors={};
        if(fields["username"].length<8){
            fvalid=false;
            errors["username"] = "*username should be more than 8 char.";
        }
        if(!fields["username"]){
            fvalid=false;
            errors["username"] = "*Please enter your username.";
        }
        if (!fields["address"]) {
            fvalid = false;
            errors["address"] = "*Please enter your Address.";
        }
        if (!fields["mobileno"]) {
            fvalid = false;
            errors["mobileno"] = "*Please enter your mobile no.";
        }
        if (fields["mobileno"].length<10) {
            fvalid = false;
            errors["mobileno"] = "*Please enter valid mobile number.";
        }
        if (fields["password"].length<8) {
            fvalid = false;
            errors["password"] = "*Please enter more than 8 character.";
        }
        if (!fields["password"]) {
            fvalid = false;
            errors["password"] = "*Please enter your password";
        }
        if (fields["repassword"]!=fields["password"]) {
            fvalid = false;
            errors["repassword"] = "*Confirm Password doesn't match with Password.";
        }
        if (!fields["repassword"]) {
            fvalid = false;
            errors["repassword"] = "*Please enter your password";
        }
    
        this.setState({
            errors:errors
        });
        return fvalid;
    }
   render(){
    return(
        <table id="table" cellSpacing={2}>
            <tr>
                <td align="center">
        <div id="main-registration-container">
            <div id="register">
            <label>Register New Vendor</label><br></br>
                <form method="post" name="userRegistrationForm" onSubmit={this.submituserRegistrationForm}>
                        <input type="text" name="username" value={this.state.fields.username} onChange={this.handleChange} placeholder="Enter Name"/>
                        <div className="errorMsg">{this.state.errors.username}</div>

                        <input type="text" name="mobileno" value={this.state.fields.mobileno} onChange={this.handleChange} placeholder="Enter Phone Number"/>
                        <div className="errorMsg">{this.state.errors.mobileno}</div>
                        
                        <input type="text" name="address" value={this.state.fields.address} onChange={this.handleChange} placeholder="Enter Address"/>
                        <div className="errorMsg">{this.state.errors.Address}</div>
                        <input type="password" name="password" value={this.state.fields.password} onChange={this.handleChange} placeholder="Enter Password"/>
                        <div className="errorMsg">{this.state.errors.password}</div>
                        <input type="password" name="repassword" value={this.state.fields.repassword} onChange={this.handleChange} placeholder="Retype Password"/>
                        <div className="errorMsg">{this.state.errors.repassword}</div>
                        <input type="submit" className="button" value="Submit" />
                </form>
            </div>
        </div>
        </td>

        <td>
        <td align="center">
                        <img src="./img/pharmacy.jpg" className="images" />
        </td>
            </td>
            </tr>
           </table>
    );
   }
}
export default Pharma