import axios from "axios";
const EMPLOYEE_API_BASE_URL = 'https://datausa.io/api/data?drilldowns=Nation&measures=Population';

class Service {

    getComponent() {
        return axios.get(EMPLOYEE_API_BASE_URL);
    }
}

export default new Service();