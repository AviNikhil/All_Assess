import React,{useState,useEffect} from "react";
import './Loading.css';
function Loading(){
    const [loading, setLoading] = useState(false);
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  }, []);
          let completed=' '
          return (
            <body className="body">
            <center><img src="./img/react.jpg" className="images" /></center>
              {!completed ? (
                <>
                  {!loading ? (
                    <div className="spinner">
                      <span>Loading...</span>
                      <div className="half-spinner"></div>
                    </div>
                  ) : (
                    <div className="completed">&#x2713;</div>
                  )}
                </>
              ) : (
                <>
                </>
              )}
            </body>
          );

}
export default Loading